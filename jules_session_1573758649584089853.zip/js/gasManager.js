class GasManager {
    constructor() {
        this.gasMap = {}; // { "z,y,x": { type, density, sourceId, duration } }
        this.nextGasId = 1;
        this.activeGases = []; // List of active gas cloud centers/sources for optimization? 
                               // Or just iterate the map? Iterating full map is slow.
                               // Better: list of active gas tiles.
        
        this.gasDefinitions = {
            'smoke': {
                color: '#888888',
                sprites: ['░', '▒', '▓'],
                opacityPerDensity: 0.3,
                dissipationRate: 0.1, // Density loss per turn
                spreadRate: 0.5, // Chance to spread to neighbor
                blocksVision: true,
                maxDensity: 3.0,
                effects: { "in_smoke": { duration: 1, type: 'status' } }
            },
            'tear_gas': {
                color: '#B8B868',
                sprites: ['~', ';', ','],
                opacityPerDensity: 0.1,
                dissipationRate: 0.2,
                spreadRate: 0.4,
                blocksVision: false, // Less blocking than smoke
                maxDensity: 2.0,
                effects: { "irritated_tear_gas": { duration: 1, type: 'status' } }
            },
            'steam': {
                color: '#E0E0E0',
                sprites: ['☁', '~', ' '],
                opacityPerDensity: 0.2,
                dissipationRate: 0.3,
                spreadRate: 0.2,
                blocksVision: true,
                maxDensity: 1.5,
                effects: { "wet": { duration: 1, type: 'status' } } // Example
            }
        };
    }

    init(gameState) {
        if (!gameState.gasSystem) {
            gameState.gasSystem = {
                tiles: {} // Store simplified data in gameState for save/load
            };
        }
        this.gasMap = gameState.gasSystem.tiles || {};
    }

    addGas(x, y, z, type, density, duration = 5) {
        const key = `${z},${y},${x}`;
        // console.log(`GasManager.addGas called for ${key}, type: ${type}`);
        if (!this.gasDefinitions[type]) {
            console.warn(`Unknown gas type: ${type}`);
            return;
        }

        if (!this.gasMap[key]) {
            this.gasMap[key] = {
                x, y, z,
                type: type,
                density: density,
                duration: duration
            };
        } else {
            // Merge or cap?
            const tile = this.gasMap[key];
            if (tile.type === type) {
                tile.density = Math.min(tile.density + density, this.gasDefinitions[type].maxDensity);
                tile.duration = Math.max(tile.duration, duration);
            } else {
                // Overwrite if new gas is denser? Or mix? 
                // For simplicity, denser wins or replace.
                if (density > tile.density) {
                    tile.type = type;
                    tile.density = density;
                    tile.duration = duration;
                }
            }
        }
    }

    getGasAt(x, y, z) {
        const key = `${z},${y},${x}`;
        return this.gasMap[key];
    }

    processTurn() {
        const changes = {}; // Store updates to avoid modifying while iterating
        const removals = [];

        // 1. Spread and Dissipate
        for (const key in this.gasMap) {
            const gas = this.gasMap[key];
            const def = this.gasDefinitions[gas.type];

            // Dissipate
            gas.density -= def.dissipationRate;
            gas.duration--;

            if (gas.density <= 0 || gas.duration <= 0) {
                removals.push(key);
                continue;
            }

            // Spread
            // Simple cellular automata: spread to neighbors with lower density
            // 3D neighbors? Yes.
            const neighbors = [
                { dx: 0, dy: -1, dz: 0 }, { dx: 0, dy: 1, dz: 0 },
                { dx: -1, dy: 0, dz: 0 }, { dx: 1, dy: 0, dz: 0 },
                { dx: 0, dy: 0, dz: 1 }, { dx: 0, dy: 0, dz: -1 } // Vertical spread!
            ];

            neighbors.forEach(n => {
                const nx = gas.x + n.dx;
                const ny = gas.y + n.dy;
                const nz = gas.z + n.dz;
                const nKey = `${nz},${ny},${nx}`;

                // Check collision/blocking tiles before spreading?
                // Using global mapRenderer or similar helper
                if (this.isBlocked(gas.x, gas.y, gas.z, nx, ny, nz)) return;

                const existing = this.gasMap[nKey] || changes[nKey];
                
                // Spread logic: Move some density to empty or lower density neighbors
                if (!existing && Math.random() < def.spreadRate) {
                    // Create new gas tile
                    if (!changes[nKey]) {
                        changes[nKey] = {
                            x: nx, y: ny, z: nz,
                            type: gas.type,
                            density: gas.density * 0.5, // Decay on spread
                            duration: gas.duration - 1
                        };
                    }
                } else if (existing && existing.type === gas.type && existing.density < gas.density) {
                    // Equalize
                    const diff = (gas.density - existing.density) * 0.1;
                    if (diff > 0.1) {
                        // We can't easily modify 'existing' if it's in gasMap directly inside this loop without side effects
                        // But since we are iterating keys, we might process 'existing' later or processed it already.
                        // Standard CA uses buffer.
                        // For simplicity in JS turn-based:
                        // Just push a "delta" to apply later? 
                        // Or just allow immediate propagation (can be directional bias).
                        // Let's use 'changes' map for NEW tiles only, and update existing in place cautiously?
                        // Actually, simplified: Spread only to empty spots or very low density spots for visual expansion.
                    }
                }
            });
        }

        // Apply new tiles
        for (const key in changes) {
            // Double check it wasn't populated by another neighbor in this same turn loop (race condition in loop)
            // But 'changes' is a map, so last write wins, which is fine.
            if (!this.gasMap[key]) {
                this.gasMap[key] = changes[key];
            } else {
                 // If it exists now (rare), merge?
                 // Ignore for now.
            }
        }

        // Remove expired
        removals.forEach(key => delete this.gasMap[key]);
        
        // Sync to gameState
        if (window.gameState && window.gameState.gasSystem) {
            window.gameState.gasSystem.tiles = this.gasMap;
        }

        if (window.mapRenderer) window.mapRenderer.scheduleRender();
    }

    isBlocked(x1, y1, z1, x2, y2, z2) {
        // Use mapRenderer.getCollisionTileAt or similar
        // Gas can generally pass through open space.
        // It is blocked by walls (middle layer blocking) and floors (bottom layer) if moving vertically.
        
        if (!window.mapRenderer) return false;

        // Moving horizontally
        if (z1 === z2) {
            // Check target tile for blocking wall
            const tile = window.mapRenderer.getCollisionTileAt(x2, y2, z2);
            if (tile) return true; // Wall blocks gas
        } 
        // Moving Vertically
        else {
            // Up or Down
            // Check for floor/ceiling between z1 and z2.
            const lowerZ = Math.min(z1, z2);
            // Floor at z+1 bottom? Ceiling?
            // "Standing logic": Bottom layer of Z is floor.
            // If moving Z to Z+1 (Up): Need to pass through Z+1 Bottom (Floor).
            // If moving Z to Z-1 (Down): Need to pass through Z Bottom (Floor).
            
            // Simplified: Check bottom layer of the Higher Z.
            const higherZ = Math.max(z1, z2);
            
            // We need to check if there is a floor at higherZ.
            // Actually, getCollisionTileAt checks middle layer. We need to check bottom layer for floors.
            const mapData = window.mapRenderer.getCurrentMapData();
            if (mapData && mapData.levels && mapData.levels[higherZ]) {
                const bottom = mapData.levels[higherZ].bottom;
                if (bottom && bottom[y1] && bottom[y1][x1]) {
                    const tileId = (typeof bottom[y1][x1] === 'object') ? bottom[y1][x1].tileId : bottom[y1][x1];
                    if (tileId) return true; // Floor blocks gas vertical movement
                }
            }
        }
        
        return false;
    }

    // Helper for LOS
    getOpacityAt(x, y, z) {
        const gas = this.getGasAt(x, y, z);
        if (!gas) return 0;
        const def = this.gasDefinitions[gas.type];
        if (!def || !def.blocksVision) return 0;
        return Math.min(1.0, gas.density * def.opacityPerDensity);
    }
}

window.GasManager = GasManager;
window.gasManager = new GasManager();
console.log("js/gasManager.js loaded and instantiated.");
